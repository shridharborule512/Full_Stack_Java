import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Timer, Trophy, RotateCcw, Lightbulb } from "lucide-react";

const words = [
  { word: "KNOWLEDGE", hint: "Information and understanding" },
  { word: "PRACTICE", hint: "Repeated exercise to improve" },
  { word: "FLUENCY", hint: "Ability to speak smoothly" },
  { word: "VOCABULARY", hint: "Words used in a language" },
  { word: "GRAMMAR", hint: "Rules of language structure" },
];

export function WordPuzzle() {
  const [currentWord, setCurrentWord] = useState(words[0]);
  const [scrambled, setScrambled] = useState("");
  const [userInput, setUserInput] = useState("");
  const [score, setScore] = useState(0);
  const [timer, setTimer] = useState(60);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);

  useEffect(() => {
    scrambleWord(currentWord.word);
  }, [currentWord]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (gameStarted && !gameOver && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            setGameOver(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [gameStarted, gameOver, timer]);

  const scrambleWord = (word: string) => {
    const scrambled = word
      .split("")
      .sort(() => Math.random() - 0.5)
      .join("");
    setScrambled(scrambled);
  };

  const handleSubmit = () => {
    if (!gameStarted) setGameStarted(true);
    
    if (userInput.toUpperCase() === currentWord.word) {
      setScore((prev) => prev + (showHint ? 5 : 10));
      setFeedback("correct");
      setTimeout(() => {
        const nextIndex = (words.indexOf(currentWord) + 1) % words.length;
        setCurrentWord(words[nextIndex]);
        setUserInput("");
        setShowHint(false);
        setFeedback(null);
      }, 1000);
    } else {
      setFeedback("incorrect");
      setTimeout(() => setFeedback(null), 800);
    }
  };

  const resetGame = () => {
    setCurrentWord(words[0]);
    setUserInput("");
    setScore(0);
    setTimer(60);
    setGameStarted(false);
    setGameOver(false);
    setShowHint(false);
    setFeedback(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <Badge variant="secondary" className="text-base" data-testid="text-score">
            <Trophy className="mr-2 h-4 w-4" />
            Score: {score}
          </Badge>
          <Badge
            variant="secondary"
            className={`text-base ${timer <= 10 ? "bg-destructive/20 text-destructive" : ""}`}
            data-testid="text-timer"
          >
            <Timer className="mr-2 h-4 w-4" />
            {timer}s
          </Badge>
        </div>
        <Button variant="outline" onClick={resetGame} data-testid="button-reset-game">
          <RotateCcw className="mr-2 h-4 w-4" />
          Reset
        </Button>
      </div>

      {gameOver ? (
        <Card className="border-2 border-primary">
          <CardContent className="pt-6 text-center">
            <Trophy className="h-12 w-12 text-primary mx-auto mb-3" />
            <h3 className="text-2xl font-bold mb-2">Time's Up!</h3>
            <p className="text-muted-foreground mb-4">Final Score: {score} points</p>
            <Button onClick={resetGame} data-testid="button-play-again">
              Play Again
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className={`transition-all duration-300 ${
          feedback === "correct" ? "border-2 border-success bg-success/5" :
          feedback === "incorrect" ? "border-2 border-destructive bg-destructive/5" : ""
        }`}>
          <CardContent className="pt-6 space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-muted-foreground mb-4">
                Unscramble this word:
              </h3>
              <div className="flex justify-center gap-2 mb-6">
                {scrambled.split("").map((letter, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 flex items-center justify-center bg-primary/10 border-2 border-primary rounded-md text-xl font-bold"
                    data-testid={`letter-${index}`}
                  >
                    {letter}
                  </div>
                ))}
              </div>
              {showHint && (
                <p className="text-muted-foreground mb-4">
                  <Lightbulb className="inline h-4 w-4 mr-2" />
                  Hint: {currentWord.hint}
                </p>
              )}
            </div>

            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Type your answer..."
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                className="flex-1"
                data-testid="input-word-answer"
              />
              <Button onClick={handleSubmit} data-testid="button-submit-answer">
                Submit
              </Button>
            </div>

            {!showHint && (
              <Button
                variant="ghost"
                onClick={() => setShowHint(true)}
                className="w-full"
                data-testid="button-show-hint"
              >
                <Lightbulb className="mr-2 h-4 w-4" />
                Show Hint (-5 points)
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
