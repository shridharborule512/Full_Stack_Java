import { AchievementBadge } from "../AchievementBadge";

export default function AchievementBadgeExample() {
  return (
    <div className="max-w-md space-y-4">
      <AchievementBadge
        title="First Victory"
        description="Complete your first game"
        tier="bronze"
        unlocked={true}
      />
      <AchievementBadge
        title="Word Master"
        description="Score perfect in 10 games"
        tier="gold"
        progress={60}
        unlocked={false}
      />
    </div>
  );
}
