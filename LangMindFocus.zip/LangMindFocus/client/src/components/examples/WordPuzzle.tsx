import { WordPuzzle } from "../WordPuzzle";

export default function WordPuzzleExample() {
  return <WordPuzzle />;
}
