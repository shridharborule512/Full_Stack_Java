import { StatsCard } from "../StatsCard";
import { Trophy } from "lucide-react";

export default function StatsCardExample() {
  return (
    <div className="max-w-xs">
      <StatsCard
        title="Games Played"
        value={42}
        icon={Trophy}
        color="primary"
      />
    </div>
  );
}
