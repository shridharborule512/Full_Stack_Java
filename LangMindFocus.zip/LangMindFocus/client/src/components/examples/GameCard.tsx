import { GameCard } from "../GameCard";
import memoryIcon from "@assets/stock_images/memory_cards_with_sp_6ba9a323.jpg";

export default function GameCardExample() {
  return (
    <div className="max-w-sm">
      <GameCard
        title="Memory Match"
        description="Match English words with their definitions"
        icon={memoryIcon}
        difficulty="Easy"
        onPlay={() => console.log("Play clicked")}
      />
    </div>
  );
}
