import { MemoryGame } from "../MemoryGame";

export default function MemoryGameExample() {
  return <MemoryGame />;
}
