import { SpeedChallenge } from "../SpeedChallenge";

export default function SpeedChallengeExample() {
  return <SpeedChallenge />;
}
