import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Trophy, Lock } from "lucide-react";

interface AchievementBadgeProps {
  title: string;
  description: string;
  tier: "bronze" | "silver" | "gold";
  progress?: number;
  unlocked?: boolean;
}

const tierConfig = {
  bronze: {
    bg: "bg-achievement-bronze",
    text: "text-achievement-bronze-foreground",
    border: "border-achievement-bronze",
  },
  silver: {
    bg: "bg-achievement-silver",
    text: "text-achievement-silver-foreground",
    border: "border-achievement-silver",
  },
  gold: {
    bg: "bg-achievement-gold",
    text: "text-achievement-gold-foreground",
    border: "border-achievement-gold",
  },
};

export function AchievementBadge({
  title,
  description,
  tier,
  progress = 0,
  unlocked = false,
}: AchievementBadgeProps) {
  const config = tierConfig[tier];

  return (
    <Card className={`${unlocked ? "border-2 " + config.border : "opacity-60"}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start gap-3">
          <div
            className={`p-3 rounded-full ${unlocked ? config.bg + " " + config.text : "bg-muted text-muted-foreground"}`}
          >
            {unlocked ? (
              <Trophy className="h-6 w-6" data-testid={`icon-achievement-${tier}`} />
            ) : (
              <Lock className="h-6 w-6" />
            )}
          </div>
          <div className="flex-1">
            <CardTitle className="text-lg font-bold" data-testid={`text-achievement-${title.toLowerCase().replace(/\s+/g, "-")}`}>
              {title}
            </CardTitle>
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
          </div>
        </div>
      </CardHeader>
      {!unlocked && progress > 0 && (
        <CardContent>
          <Progress value={progress} className="h-2" />
          <p className="text-xs text-muted-foreground mt-2">{progress}% complete</p>
        </CardContent>
      )}
    </Card>
  );
}
