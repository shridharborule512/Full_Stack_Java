import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Timer, Trophy, RotateCcw } from "lucide-react";

interface MemoryCard {
  id: number;
  word: string;
  definition: string;
  type: "word" | "definition";
  matched: boolean;
}

const wordPairs = [
  { word: "Benevolent", definition: "Kind and generous" },
  { word: "Ephemeral", definition: "Lasting for a short time" },
  { word: "Pragmatic", definition: "Practical and realistic" },
  { word: "Resilient", definition: "Able to recover quickly" },
  { word: "Verbose", definition: "Using too many words" },
  { word: "Zealous", definition: "Very enthusiastic" },
];

export function MemoryGame() {
  const [cards, setCards] = useState<MemoryCard[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [timer, setTimer] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameWon, setGameWon] = useState(false);

  useEffect(() => {
    initializeGame();
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (gameStarted && !gameWon) {
      interval = setInterval(() => {
        setTimer((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [gameStarted, gameWon]);

  const initializeGame = () => {
    const gameCards: MemoryCard[] = [];
    wordPairs.forEach((pair, index) => {
      gameCards.push({
        id: index * 2,
        word: pair.word,
        definition: pair.definition,
        type: "word",
        matched: false,
      });
      gameCards.push({
        id: index * 2 + 1,
        word: pair.word,
        definition: pair.definition,
        type: "definition",
        matched: false,
      });
    });
    setCards(gameCards.sort(() => Math.random() - 0.5));
    setFlipped([]);
    setMatched([]);
    setMoves(0);
    setTimer(0);
    setGameStarted(false);
    setGameWon(false);
  };

  const handleCardClick = (id: number) => {
    if (!gameStarted) setGameStarted(true);
    if (flipped.length === 2 || flipped.includes(id) || matched.includes(id)) return;

    const newFlipped = [...flipped, id];
    setFlipped(newFlipped);

    if (newFlipped.length === 2) {
      setMoves((prev) => prev + 1);
      const [first, second] = newFlipped;
      const firstCard = cards.find((c) => c.id === first);
      const secondCard = cards.find((c) => c.id === second);

      if (firstCard?.word === secondCard?.word) {
        setMatched([...matched, first, second]);
        setFlipped([]);
        
        if (matched.length + 2 === cards.length) {
          setGameWon(true);
        }
      } else {
        setTimeout(() => setFlipped([]), 1000);
      }
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <Badge variant="secondary" className="text-base" data-testid="text-moves">
            <Trophy className="mr-2 h-4 w-4" />
            Moves: {moves}
          </Badge>
          <Badge variant="secondary" className="text-base" data-testid="text-timer">
            <Timer className="mr-2 h-4 w-4" />
            {formatTime(timer)}
          </Badge>
        </div>
        <Button variant="outline" onClick={initializeGame} data-testid="button-reset-game">
          <RotateCcw className="mr-2 h-4 w-4" />
          Reset
        </Button>
      </div>

      {gameWon && (
        <Card className="border-2 border-success bg-success/5">
          <CardContent className="pt-6 text-center">
            <Trophy className="h-12 w-12 text-success mx-auto mb-3" />
            <h3 className="text-2xl font-bold mb-2">Congratulations!</h3>
            <p className="text-muted-foreground">
              You won in {moves} moves and {formatTime(timer)}!
            </p>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {cards.map((card) => (
          <Card
            key={card.id}
            className={`cursor-pointer transition-all duration-300 hover-elevate active-elevate-2 ${
              flipped.includes(card.id) || matched.includes(card.id)
                ? matched.includes(card.id)
                  ? "border-2 border-success bg-success/10"
                  : "border-2 border-primary bg-primary/10"
                : "bg-card"
            }`}
            onClick={() => handleCardClick(card.id)}
            data-testid={`card-memory-${card.id}`}
          >
            <CardContent className="p-4 h-28 flex items-center justify-center">
              {flipped.includes(card.id) || matched.includes(card.id) ? (
                <p className="text-center font-semibold text-sm">
                  {card.type === "word" ? card.word : card.definition}
                </p>
              ) : (
                <div className="w-12 h-12 rounded-full bg-primary/20" />
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
