import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Lock } from "lucide-react";

interface GameCardProps {
  title: string;
  description: string;
  icon: string;
  difficulty: "Easy" | "Medium" | "Hard";
  locked?: boolean;
  onPlay: () => void;
}

const difficultyColors = {
  Easy: "bg-success/10 text-success border-success/20",
  Medium: "bg-warning/10 text-warning border-warning/20",
  Hard: "bg-destructive/10 text-destructive border-destructive/20",
};

export function GameCard({ title, description, icon, difficulty, locked = false, onPlay }: GameCardProps) {
  return (
    <Card className="overflow-hidden hover-elevate transition-all duration-300">
      <div className="h-32 overflow-hidden">
        <img
          src={icon}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <CardHeader className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-xl font-bold font-[family-name:var(--font-sans)]">{title}</CardTitle>
          <Badge className={`${difficultyColors[difficulty]} border`} data-testid={`badge-difficulty-${difficulty.toLowerCase()}`}>
            {difficulty}
          </Badge>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <Button
          className="w-full"
          onClick={onPlay}
          disabled={locked}
          data-testid={`button-play-${title.toLowerCase().replace(/\s+/g, "-")}`}
        >
          {locked ? (
            <>
              <Lock className="mr-2 h-4 w-4" />
              Locked
            </>
          ) : (
            <>
              <Play className="mr-2 h-4 w-4" />
              Play Game
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
