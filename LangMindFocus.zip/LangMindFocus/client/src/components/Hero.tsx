import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import heroImage from "@assets/stock_images/abstract_colorful_br_d179ad89.jpg";

interface HeroProps {
  onGetStarted: () => void;
}

export function Hero({ onGetStarted }: HeroProps) {
  return (
    <div className="relative h-[60vh] min-h-[400px] flex items-center justify-center overflow-hidden rounded-2xl">
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Brain training illustration"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-black/70 via-black/50 to-black/70" />
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-3xl">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 font-[family-name:var(--font-sans)] tracking-tight">
          Train Your Brain in English
        </h1>
        <p className="text-lg md:text-xl text-white/90 mb-8 font-[family-name:var(--font-sans)]">
          Master vocabulary through fun daily games. Build streaks, earn achievements, and watch your skills grow.
        </p>
        <Button
          size="lg"
          className="bg-primary text-primary-foreground hover-elevate active-elevate-2 border border-primary-border text-lg h-12 px-8"
          onClick={onGetStarted}
          data-testid="button-get-started"
        >
          <Sparkles className="mr-2 h-5 w-5" />
          Start Learning
        </Button>
      </div>
    </div>
  );
}
