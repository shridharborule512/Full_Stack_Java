import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Timer, Trophy, RotateCcw, Zap } from "lucide-react";

const questions = [
  { word: "Happy", answer: "Joyful", type: "synonym" },
  { word: "Big", answer: "Large", type: "synonym" },
  { word: "Fast", answer: "Quick", type: "synonym" },
  { word: "Smart", answer: "Intelligent", type: "synonym" },
  { word: "Brave", answer: "Courageous", type: "synonym" },
  { word: "Angry", answer: "Mad", type: "synonym" },
  { word: "Sad", answer: "Unhappy", type: "synonym" },
  { word: "Beautiful", answer: "Pretty", type: "synonym" },
];

export function SpeedChallenge() {
  const [currentQuestion, setCurrentQuestion] = useState(questions[0]);
  const [userInput, setUserInput] = useState("");
  const [score, setScore] = useState(0);
  const [timer, setTimer] = useState(30);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [streak, setStreak] = useState(0);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (gameStarted && !gameOver && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            setGameOver(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [gameStarted, gameOver, timer]);

  const handleSubmit = () => {
    if (!gameStarted) setGameStarted(true);

    const isCorrect = userInput.toLowerCase().trim() === currentQuestion.answer.toLowerCase();
    
    if (isCorrect) {
      const points = (streak + 1) * 10;
      setScore((prev) => prev + points);
      setStreak((prev) => prev + 1);
      setQuestionsAnswered((prev) => prev + 1);
      
      const nextIndex = (questions.indexOf(currentQuestion) + 1) % questions.length;
      setCurrentQuestion(questions[nextIndex]);
      setUserInput("");
    } else {
      setStreak(0);
      setUserInput("");
    }
  };

  const resetGame = () => {
    setCurrentQuestion(questions[0]);
    setUserInput("");
    setScore(0);
    setTimer(30);
    setGameStarted(false);
    setGameOver(false);
    setStreak(0);
    setQuestionsAnswered(0);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <Badge variant="secondary" className="text-base" data-testid="text-score">
            <Trophy className="mr-2 h-4 w-4" />
            Score: {score}
          </Badge>
          <Badge variant="secondary" className="text-base" data-testid="text-streak">
            <Zap className="mr-2 h-4 w-4" />
            Streak: {streak}
          </Badge>
          <Badge
            variant="secondary"
            className={`text-base ${timer <= 10 ? "bg-destructive/20 text-destructive" : ""}`}
            data-testid="text-timer"
          >
            <Timer className="mr-2 h-4 w-4" />
            {timer}s
          </Badge>
        </div>
        <Button variant="outline" onClick={resetGame} data-testid="button-reset-game">
          <RotateCcw className="mr-2 h-4 w-4" />
          Reset
        </Button>
      </div>

      {gameOver ? (
        <Card className="border-2 border-primary">
          <CardContent className="pt-6 text-center">
            <Trophy className="h-12 w-12 text-primary mx-auto mb-3" />
            <h3 className="text-2xl font-bold mb-2">Time's Up!</h3>
            <p className="text-muted-foreground mb-2">Final Score: {score} points</p>
            <p className="text-muted-foreground mb-4">Questions Answered: {questionsAnswered}</p>
            <Button onClick={resetGame} data-testid="button-play-again">
              Play Again
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-2 border-primary">
          <CardContent className="pt-6 space-y-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Find a synonym for:</p>
              <h3 className="text-4xl font-bold text-primary mb-4" data-testid="text-current-word">
                {currentQuestion.word}
              </h3>
              {streak > 0 && (
                <Badge className="bg-warning text-warning-foreground">
                  <Zap className="mr-1 h-3 w-3" />
                  {streak}x Multiplier!
                </Badge>
              )}
            </div>

            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Type your answer..."
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                className="flex-1 text-lg"
                autoFocus
                data-testid="input-speed-answer"
              />
              <Button onClick={handleSubmit} size="lg" data-testid="button-submit-answer">
                Submit
              </Button>
            </div>

            <p className="text-xs text-center text-muted-foreground">
              Correct answers build your streak multiplier!
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
