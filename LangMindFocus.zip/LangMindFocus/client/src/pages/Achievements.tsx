import { AchievementBadge } from "@/components/AchievementBadge";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { ThemeToggle } from "@/components/ThemeToggle";

export default function Achievements() {
  // todo: remove mock functionality
  const achievements = [
    {
      title: "First Steps",
      description: "Complete your first game",
      tier: "bronze" as const,
      unlocked: true,
    },
    {
      title: "Quick Learner",
      description: "Finish 10 games",
      tier: "bronze" as const,
      unlocked: true,
    },
    {
      title: "Dedicated Student",
      description: "Maintain a 7-day streak",
      tier: "silver" as const,
      progress: 71,
      unlocked: false,
    },
    {
      title: "Perfect Score",
      description: "Achieve 100% in any game",
      tier: "silver" as const,
      unlocked: true,
    },
    {
      title: "Speed Demon",
      description: "Complete Speed Challenge in under 20 seconds",
      tier: "gold" as const,
      progress: 45,
      unlocked: false,
    },
    {
      title: "Word Master",
      description: "Score perfect in 10 different games",
      tier: "gold" as const,
      progress: 80,
      unlocked: false,
    },
    {
      title: "Memory Champion",
      description: "Complete Memory Match without mistakes",
      tier: "gold" as const,
      unlocked: true,
    },
    {
      title: "Vocabulary Genius",
      description: "Learn 500 new words",
      tier: "gold" as const,
      progress: 60,
      unlocked: false,
    },
  ];

  const unlockedCount = achievements.filter((a) => a.unlocked).length;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold font-[family-name:var(--font-sans)]">
              Achievements
            </h1>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-2 font-[family-name:var(--font-sans)]">
            Your Achievements
          </h2>
          <p className="text-muted-foreground">
            {unlockedCount} of {achievements.length} unlocked
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievements.map((achievement, index) => (
            <AchievementBadge
              key={index}
              title={achievement.title}
              description={achievement.description}
              tier={achievement.tier}
              progress={achievement.progress}
              unlocked={achievement.unlocked}
            />
          ))}
        </div>
      </main>
    </div>
  );
}
