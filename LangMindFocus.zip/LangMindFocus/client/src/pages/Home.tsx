import { useState } from "react";
import { Hero } from "@/components/Hero";
import { GameCard } from "@/components/GameCard";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Flame, Trophy, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import memoryIcon from "@assets/stock_images/memory_cards_with_sp_6ba9a323.jpg";
import puzzleIcon from "@assets/stock_images/scrambled_letters_fo_d33bb837.jpg";
import speedIcon from "@assets/stock_images/lightning_bolt_with__b41d16aa.jpg";

export default function Home() {
  const [dailyStreak] = useState(5); // todo: remove mock functionality

  const scrollToGames = () => {
    document.getElementById("games")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold font-[family-name:var(--font-sans)] bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              BrainLingo
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <Badge className="bg-warning text-warning-foreground border-warning-border" data-testid="badge-daily-streak">
              <Flame className="mr-1 h-4 w-4" />
              {dailyStreak} Day Streak
            </Badge>
            <Link href="/dashboard">
              <Button variant="ghost" size="icon" data-testid="link-dashboard">
                <BarChart3 className="h-5 w-5" />
              </Button>
            </Link>
            <Link href="/achievements">
              <Button variant="ghost" size="icon" data-testid="link-achievements">
                <Trophy className="h-5 w-5" />
              </Button>
            </Link>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-12">
        <Hero onGetStarted={scrollToGames} />

        <section id="games" className="scroll-mt-8">
          <h2 className="text-3xl font-bold mb-6 font-[family-name:var(--font-sans)]">
            Daily Brain Games
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <GameCard
              title="Memory Match"
              description="Match English words with their definitions. Train your vocabulary recall!"
              icon={memoryIcon}
              difficulty="Easy"
              onPlay={() => (window.location.href = "/game/memory")}
            />
            <GameCard
              title="Word Puzzle"
              description="Unscramble letters to form words. Beat the clock!"
              icon={puzzleIcon}
              difficulty="Medium"
              onPlay={() => (window.location.href = "/game/puzzle")}
            />
            <GameCard
              title="Speed Challenge"
              description="Find synonyms as fast as you can. Build your streak!"
              icon={speedIcon}
              difficulty="Hard"
              onPlay={() => (window.location.href = "/game/speed")}
            />
          </div>
        </section>
      </main>
    </div>
  );
}
