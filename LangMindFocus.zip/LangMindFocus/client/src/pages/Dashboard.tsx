import { StatsCard } from "@/components/StatsCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Trophy, Target, Flame, Star } from "lucide-react";
import { Link } from "wouter";
import { ThemeToggle } from "@/components/ThemeToggle";

export default function Dashboard() {
  // todo: remove mock functionality
  const stats = {
    gamesPlayed: 42,
    perfectScores: 8,
    currentStreak: 5,
    totalPoints: 1240,
  };

  const recentGames = [
    { name: "Memory Match", score: 85, date: "Today" },
    { name: "Word Puzzle", score: 92, date: "Today" },
    { name: "Speed Challenge", score: 78, date: "Yesterday" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold font-[family-name:var(--font-sans)]">
              Progress Dashboard
            </h1>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        <section>
          <h2 className="text-2xl font-bold mb-4 font-[family-name:var(--font-sans)]">
            Your Stats
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard
              title="Games Played"
              value={stats.gamesPlayed}
              icon={Target}
              color="primary"
            />
            <StatsCard
              title="Perfect Scores"
              value={stats.perfectScores}
              icon={Trophy}
              color="success"
            />
            <StatsCard
              title="Current Streak"
              value={`${stats.currentStreak} days`}
              icon={Flame}
              color="warning"
            />
            <StatsCard
              title="Total Points"
              value={stats.totalPoints}
              icon={Star}
              color="primary"
            />
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-bold mb-4 font-[family-name:var(--font-sans)]">
            Recent Activity
          </h2>
          <Card>
            <CardHeader>
              <CardTitle>Recent Games</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentGames.map((game, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 rounded-lg hover-elevate"
                    data-testid={`game-${index}`}
                  >
                    <div>
                      <p className="font-semibold">{game.name}</p>
                      <p className="text-sm text-muted-foreground">{game.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">{game.score}</p>
                      <p className="text-sm text-muted-foreground">points</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
}
