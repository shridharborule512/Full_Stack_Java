# Design Guidelines: English Brain Games for Language Learners

## Design Approach
**Reference-Based: Gamified Learning Apps** (Duolingo, Kahoot, Memrise)
- Playful yet focused visual language that promotes learning
- Colorful, reward-driven interface encouraging daily engagement
- Clear progress visualization and achievement celebration

## Core Design Principles
1. **Joyful Learning**: Use color and animation to make brain training feel rewarding, not stressful
2. **Clarity First**: Game instructions and UI must be instantly understandable
3. **Progress Motivation**: Visual feedback celebrates every win (streaks, achievements, scores)

## Color Palette

**Light Mode:**
- Primary: 250 90% 55% (vibrant purple-blue for action buttons, active states)
- Success: 145 65% 50% (encouraging green for correct answers, achievements)
- Warning: 35 90% 60% (energetic orange for time challenges, streaks)
- Background: 220 15% 98% (soft off-white for reduced eye strain)
- Surface: 0 0% 100% (pure white for game cards, modals)
- Text: 220 20% 20% (dark blue-gray for readability)

**Dark Mode:**
- Primary: 250 85% 65% (lighter vibrant purple-blue)
- Success: 145 60% 55% (softer green)
- Warning: 35 85% 65% (softer orange)
- Background: 220 25% 12% (deep blue-black)
- Surface: 220 20% 18% (elevated card background)
- Text: 220 15% 95% (soft white)

## Typography
- **Primary Font**: 'Inter' (Google Fonts) - clean, modern, excellent at small sizes
- **Display Font**: 'Poppins' (Google Fonts) - friendly, rounded for headings and game titles
- **Sizes**: text-sm (12px), text-base (16px), text-lg (18px), text-2xl (24px), text-4xl (36px)
- **Weights**: 400 (body), 600 (emphasis), 700 (headings), 800 (game titles)

## Layout System
**Spacing Primitives**: Use tailwind units of 2, 4, 6, 8, 12, 16
- Tight spacing: p-2, gap-2 (within components)
- Standard: p-4, gap-4 (between elements)
- Generous: p-8, gap-8 (section spacing)
- Large: p-12, p-16 (page margins)

**Container Strategy:**
- Main game area: max-w-4xl mx-auto
- Dashboard: max-w-6xl mx-auto with two-column grid (stats + achievements)
- Game cards: consistent card sizing with aspect ratios

## Component Library

**Navigation:**
- Top bar with logo, streak counter (🔥 icon + number), profile avatar
- Bottom tab bar for mobile: Home, Games, Achievements, Profile
- Persistent progress indicator when in game mode

**Game Cards:**
- Rounded-2xl with subtle shadow and hover lift effect
- Icon + title + description + "Play" CTA
- Color-coded badges for difficulty (Easy/Medium/Hard)
- Lock state for unavailable games

**Memory Matching Cards:**
- Flip animation using perspective transform
- Card back: gradient with subtle pattern
- Card front: large text (word) or definition with icon
- Match celebration: scale + glow effect

**Achievement Badges:**
- Circular or shield-shaped with gradient backgrounds
- Progress rings for incomplete achievements
- Unlock animation: scale-in with confetti particle effect
- Three tiers: Bronze (30 70% 50%), Silver (0 0% 75%), Gold (45 95% 55%)

**Game UI Elements:**
- Timer: Circular progress ring in top-right
- Score counter: Animated number with +points popup
- Lives/attempts: Heart icons in top-left
- Word scramble: Individual letter tiles with drag capability
- Speed challenge: Full-width answer input with auto-complete suggestions

**Progress Dashboard:**
- Daily streak calendar with filled/empty circles
- Stats cards: Games Played, Perfect Scores, Current Streak, Total Points
- Line chart showing progress over time (Chart.js via CDN)
- Achievement showcase grid (3-4 columns on desktop)

**Modals & Overlays:**
- Game start: Instructions + difficulty selection + "Start" button
- Game complete: Score summary, stars earned (1-3), achievement unlocked banner, "Play Again" + "Next Game" CTAs
- Achievement unlock: Full-screen celebration with badge, confetti (use canvas-confetti CDN), description, "Continue" button

## Animations
**Minimal & Purposeful:**
- Card flips: 0.6s with perspective transform
- Button hovers: Scale 1.05, shadow increase
- Achievement unlocks: 0.8s scale-in entrance
- Correct answer: 0.3s green glow pulse
- Incorrect answer: 0.4s horizontal shake
- Streak milestone: Confetti burst (3s duration)

## Icons
**Heroicons** (CDN) for all UI elements:
- Games: puzzle-piece, brain, lightning-bolt
- Achievements: trophy, star, fire (streak)
- Navigation: home, chart-bar, user-circle
- Actions: play, refresh, check-circle, x-circle

## Images
**Hero Section:** YES - Include on homepage
- Large illustration of brain with puzzle pieces/gears, colorful and abstract
- Overlaid with headline "Train Your Brain in English" + primary CTA
- 60vh height on desktop, 40vh on mobile

**Game Icons:** Colorful illustrations for each game type:
- Memory Match: Cards with sparkles
- Word Puzzle: Scrambled letters forming a lightbulb
- Speed Challenge: Lightning bolt with stopwatch

Image placement: Hero (homepage), game card headers, achievement badges, empty state illustrations

## Form Elements
- Input fields: Rounded-lg, border-2, focus ring in primary color
- Dark mode: bg-surface with lighter border
- Auto-complete: Dropdown with hover states, keyboard navigation support
- Submit buttons: Full primary color, bold text, slightly larger than secondary